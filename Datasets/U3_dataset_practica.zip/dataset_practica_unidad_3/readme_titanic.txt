Acerca del conjunto de datos
Contexto
Este es un conjunto de datos clásico del Titanic ampliado con las características de la lista de pasajeros del Titanic en Wikipedia disponible a partir de febrero de 2019.

Contenido
Descripción de archivos

un conjunto completo de datos extendidos del Titanic (full.csv)
un subconjunto de entrenamiento (train.csv)
un subconjunto de prueba (test.csv)
Descripción de la característica

Las primeras 12 características son las mismas que en la competencia Titanic .

Las últimas 9 características se agregan de la lista de pasajeros del Titanic en Wikipedia y son las siguientes:

WikiId
Nombre
Edad
Ciudad natal
abordado
Destino
Bote salvavidas
Cuerpo
Clase
Las nuevas funciones son muy similares a las originales, pero están más actualizadas y tienen muchos menos valores perdidos. Por lo tanto, los usuarios pueden decidir sobre las características preferidas por sí mismos.

Referencias de Wikipedia que aparecen en el conjunto de datos

[nota 1] Ahora la República de Irlanda.

[nota 2] Ahora Alemania.

[nota 3] Ahora India.

[nota 4] Ahora Sudáfrica.

[nota 5] Ahora Tailandia.

[nota 6] Ahora Finlandia.

[nota 7] Ahora Líbano.

[59] Aunque sus empleadores viajaban en primera clase, este sirviente recibió alojamiento en segunda clase, ya que sus servicios no eran necesarios mientras sus empleadores estaban a bordo.

[60] Consulte el artículo Tripulación del RMS Titanic para obtener más información.

[61] Madeleine Astor estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a un hijo, John Jacob VI, el 14 de agosto de 1912.

[62] Helecho, Robert; Findlay, Michael (1998). "Los supervivientes más jóvenes del Titanic". Viaje. Sociedad Internacional del Titanic. 7 (27).

[63] Léontine Pauline Aubart fue la amante de Benjamin Guggenheim. Benjamin Guggenheim murió en el hundimiento.

[64] Después de que el Titanic se hundiera, Thomson Beattie fue subido a bordo del Plegable A, pero murió en la noche. Su cuerpo fue encontrado cuando el bote salvavidas fue recuperado un mes después por el Oceanic.

[65] Helen Bishop estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a un hijo, Randall Walton, el 8 de diciembre de 1912, que murió un día después de su nacimiento.

[66] William Hoyt fue sacado vivo del agua y llevado al bote salvavidas 14, y por lo tanto se cuenta entre los ocupantes de este bote; Hoyt, sin embargo, murió durante la noche y su cuerpo fue enterrado en el mar por los marineros a bordo del Carpathia.

[67] "Una víctima legalmente muerta". Los New York Times. 27 de abril de 1912. pág. 4

[68] Marion Kenyon estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a un niño que nació muerto en algún momento de 1912.

[69] "Señorita Roberta Elizabeth Mary Maioni". Enciclopedia-titanica.org. Consultado el 6 de julio de 2011.

[70] Mary Marvin estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a una hija, Margaret, en algún momento de 1912.

[71] Viajó usando alias: Baron Alfred von Drachstedt; transferido de segunda a primera clase

72 Alfred Nourney (ref: #220) Enciclopedia Titanica, (consultado el 17 de diciembre de 2013)

[73] Eloise Smith estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a un hijo, Lucien Philip Jr., el 19 de noviembre de 1912.

[74] Argene del Carlo estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a una hija, María Salvata, el 14 de noviembre de 1912.

[75] Juliette Laroche estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a un hijo, Joseph Lemercier, el 17 de diciembre de 1912.

[76] Enciclopedia Titanica Fr Juozas Montvila Consultado el 2 de abril de 2017.

[77] Adele Nasser estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a su hijo Nicolás, el 9 de diciembre de 1912, quien murió horas después de su nacimiento.

[78] Kate Phillips dio a luz a una hija, Ellen Mary "Betty", el 11 de enero de 1913. La señorita Phillips estaba teniendo una aventura con Henry Morley, y los dos se escapaban juntos.

[79] Ada West estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a una hija, Edwyna, en algún momento de 1912.

[80] Maria Backström estaba embarazada mientras estaba a bordo del Titanic. Dio a luz a una hija, Alfhild Maria, en junio de 1912.

[81] Elías, Leila Salloum. El sueño y luego la pesadilla

[82] Sr. Joseph Caram. Enciclopedia Titanica.

[83] Graziella Leporati, Quegli otto lombardi inghiottiti dall'oceano la notte del Titanic, Il Giorno.

[84] Conocido durante décadas como "El niño desconocido", el cuerpo número 4 fue identificado inicialmente después del desastre como Gösta Leonard Pålsson (1912), de dos años. Los registros dentales lo identificaron más tarde como Eino Viljami Panula (2002), de 13 meses, hasta que una prueba en el HVS1 del niño, un tipo de molécula de ADN mitocondrial, confirmó su identificación como Sidney Goodwin (2007), de 19 meses.

[85] Elías, Leila Salloum. El sueño y luego la pesadilla

[86] Debido a los efectos recuperados con el cuerpo (un monedero que contenía monedas danesas y un pañuelo marcado con la letra "A") ha habido cierta duda sobre la autenticidad de la identificación.

[87] "Maestro Walter John van Billiard". Enciclopedia Titanica. Consultado el 3 de marzo de 2008.